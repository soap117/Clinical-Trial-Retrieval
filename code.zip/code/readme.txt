see requirements.txt for the environment
Use python train_our_new.py to perform the experiment.
Due to the sensitivity of the trial studies, we can only provide the pseudo data to support the evaluation on the functionality of the proposed method.
All text and data fields are replaced with the random words. The format and structure is as same as the applied dataset.